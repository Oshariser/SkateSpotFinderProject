package com.example.iem.skatespotfinder.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Class.GroupSpotCommentary;
import com.example.iem.skatespotfinder.Class.Users;
import com.example.iem.skatespotfinder.R;

/**
 * Created by root on 1/15/15.
 */
public class MyExpandableListAdapter extends BaseExpandableListAdapter{

    private final SparseArray<GroupSpotCommentary> mGroups;
    public LayoutInflater mInflater;
    public Activity mActivity;

    public MyExpandableListAdapter(Activity aActivity, SparseArray<GroupSpotCommentary> aGroups) {
        mActivity = aActivity;
        mGroups = aGroups;
        mInflater = aActivity.getLayoutInflater();
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mGroups.get(groupPosition).getCommentaries().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final Commentary lComment = (Commentary)getChild(groupPosition, childPosition);
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.comment_row_layout, null);
        }
        TextView textViewUser = (TextView)convertView.findViewById(R.id.textViewUserName);
        TextView textViewComment = (TextView) convertView.findViewById(R.id.TextViewComment);
        TextView textViewDate = (TextView) convertView.findViewById(R.id.textViewDate);
        RatingBar ratingBar = (RatingBar) convertView.findViewById(R.id.ratingBarSpotDescription);
        textViewUser.setText(Users.getNameById(lComment.getIdUser()));
        ratingBar.setRating(lComment.getRating());
        textViewComment.setText(lComment.getDescription());
        textViewDate.setText(lComment.getDate());

        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return mGroups.get(groupPosition).getCommentaries().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mGroups.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return mGroups.size();
    }

    @Override
    public void onGroupCollapsed(int groupPosition) {
        super.onGroupCollapsed(groupPosition);
    }

    @Override
    public void onGroupExpanded(int groupPosition) {
        super.onGroupExpanded(groupPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return 0;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.row_layout, null);
        }
        final GroupSpotCommentary group = (GroupSpotCommentary) getGroup(groupPosition);
        ImageView lImageView = (ImageView)convertView.findViewById(R.id.imageView);
        TextView lTextView = (TextView)convertView.findViewById(R.id.textView);
        ImageButton lImageButton = (ImageButton)convertView.findViewById(R.id.imageButton);
        lImageView.setFocusable(false);
        lTextView.setFocusable(false);
        lImageButton.setFocusable(false);
        lImageView.setImageBitmap(group.getSpot().getBitmapImage());
        lTextView.setText(group.getSpot().getDescription());

        lImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("google.navigation:q=" + group.getSpot().getLatitude() + "," + group.getSpot().getLongitude()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mActivity.startActivity(intent);
            }
        });

        /*convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent lIntentSpotDetail = new Intent(mActivity, SpotDetailActivity.class);
                lIntentSpotDetail.putExtra("Spot", group.getSpot());
                mActivity.startActivity(lIntentSpotDetail);
                return true;
            }
        });*/
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return false;
    }
}
