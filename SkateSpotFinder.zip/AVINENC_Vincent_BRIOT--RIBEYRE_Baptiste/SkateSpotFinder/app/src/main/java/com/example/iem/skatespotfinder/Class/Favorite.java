package com.example.iem.skatespotfinder.Class;

/**
 * Created by iem on 14/01/15.
 */
public class Favorite {

    private String mId;
    private String mIdUser;
    private String mIdSpot;

    public Favorite(String aId, String aIdUser, String aIdSpot){
        this.setId(aId);
        this.setIdUser(aIdUser);
        this.setIdSpot(aIdSpot);
    }

    public String getId() {
        return mId;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public String getIdUser() {
        return mIdUser;
    }

    public void setIdUser(String mIdUser) {
        this.mIdUser = mIdUser;
    }

    public String getIdSpot() {
        return mIdSpot;
    }

    public void setIdSpot(String mIdSpot) {
        this.mIdSpot = mIdSpot;
    }
}
