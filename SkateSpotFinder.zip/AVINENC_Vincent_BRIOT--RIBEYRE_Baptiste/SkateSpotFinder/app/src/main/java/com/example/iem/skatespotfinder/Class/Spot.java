package com.example.iem.skatespotfinder.Class;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

/**
 * Created by root on 1/8/15.
 */
public class Spot implements Serializable{

    private String mId;
    private double mLatitude;
    private double mLongitude;
    private byte[] mImage;
    private float mRating;
    private String mDescription;
    private String mIdUser;


    public Spot(String aId, double aLatitude, double aLongitude, byte[] aImage, float aRating, String aDescription, String aIdUser) {
        this.mId = aId;
        this.mLatitude = aLatitude;
        this.mLongitude = aLongitude;
        this.mImage = aImage;
        this.mRating = aRating;
        this.mDescription = aDescription;
        this.mIdUser = aIdUser;
    }

    public Spot(double aLatitude, double aLongitude, File aImage, String aDescription, String aIdUser) {
        this.setLatitude(aLatitude);
        this.setLongitude(aLongitude);
        this.setImage(aImage);
        this.setDescription(aDescription);
        this.setIdUser(aIdUser);
    }

    public double getLongitude() {
        return mLongitude;
    }

    public void setLongitude(double aLongitude) {
        this.mLongitude = aLongitude;
    }

    public double getLatitude() {
        return mLatitude;
    }

    public void setLatitude(double aLatitude) {
        this.mLatitude = aLatitude;
    }

    public byte[] getImage() {
        return mImage;
    }

    public void setImage(File aImage) {
        byte[] lByte = new byte[(int) aImage.length()];
        try {
            FileInputStream lFileInputStream = new FileInputStream(aImage);
            lFileInputStream.read(lByte);
            lFileInputStream.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        this.mImage = lByte;
    }

    public float getRating() {
        return mRating;
    }

    public void setRating(float aRating) {
        this.mRating = aRating;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String aDescription) {
        this.mDescription = aDescription;
    }

    public Bitmap getBitmapImage() {
        Bitmap bitmap = BitmapFactory.decodeByteArray(mImage, 0, mImage.length);
        return bitmap;
    }

    public String getId() {
        return mId;
    }

    public void setId(String aId) {
        this.mId = aId;
    }

    public String getIdUser() {
        return mIdUser;
    }

    public void setIdUser(String aIdUser) {
        this.mIdUser = aIdUser;
    }


}
