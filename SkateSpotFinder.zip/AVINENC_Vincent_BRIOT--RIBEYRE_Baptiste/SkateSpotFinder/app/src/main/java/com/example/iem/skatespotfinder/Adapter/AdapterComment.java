package com.example.iem.skatespotfinder.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Users;

import java.util.List;

/**
 * Created by root on 1/14/15.
 */
public class AdapterComment extends ArrayAdapter{

    private final List<Commentary> mCommentaries;
    private Activity mContext;

    public AdapterComment(Activity aContext, List<Commentary> aCommentaries) {
        super(aContext, R.layout.comment_row_layout, aCommentaries);
        this.mContext = aContext;
        this.mCommentaries = aCommentaries;
    }

    static class ViewHolder {
        protected TextView textViewUserName;
        protected RatingBar ratingBar;
        protected TextView textViewComment;
        protected TextView textViewDate;
    }

    @Override
    public View getView(final int aPosition, View aConvertView, ViewGroup aParent) {
        View lView = null;
        if (aConvertView == null) {
            LayoutInflater lInflator = mContext.getLayoutInflater();
            lView = lInflator.inflate(R.layout.comment_row_layout, null);
            final ViewHolder lViewHolder = new ViewHolder();
            lViewHolder.textViewUserName = (TextView)lView.findViewById(R.id.textViewUserName);
            lViewHolder.textViewComment = (TextView)lView.findViewById(R.id.TextViewComment);
            lViewHolder.textViewDate = (TextView)lView.findViewById(R.id.textViewDate);
            lViewHolder.ratingBar = (RatingBar)lView.findViewById((R.id.ratingBarSpotDescription));
            lView.setTag(lViewHolder);
        } else {
            lView = aConvertView;
        }
        ViewHolder holder = (ViewHolder) lView.getTag();
        holder.textViewUserName.setText(Users.getNameById(mCommentaries.get(aPosition).getIdUser()));
        holder.ratingBar.setRating(mCommentaries.get(aPosition).getRating());
        holder.textViewDate.setText(mCommentaries.get(aPosition).getDate());
        holder.textViewComment.setText(mCommentaries.get(aPosition).getDescription());

        return lView;
    }

}
