package com.example.iem.skatespotfinder.Services;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.example.iem.skatespotfinder.Activities.MainActivity;
import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Class.Favorite;
import com.example.iem.skatespotfinder.Class.Spot;
import com.example.iem.skatespotfinder.Class.User;
import com.example.iem.skatespotfinder.Static;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by iem on 12/01/15.
 */
public class DataLoader extends Service{

    public static ArrayList<Spot> mSpots;
    public static ArrayList<Commentary> mCommentaries;
    public static ArrayList<User> mUsers;
    public static ArrayList<Favorite> mFavorites;
    public static ArrayList<HashMap<String, Object>> mNews;
    private static final String SUCCESS = "success";
    private final static int INTERVAL = 1000 * 60 * Static.mSynchronizationData;
    private Runnable mHandlerTask;
    Handler mHandler = new Handler();
    //------------------------------------------------------------ récupère la liste des spots

    public void getListSpots() {
        mSpots = new ArrayList<Spot>();
        ParseQuery lParseQuery = new ParseQuery("Spot");
        lParseQuery.orderByDescending("createdAt");
        lParseQuery.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> aListParseObject, ParseException e) {
                Intent lIntent = new Intent();
                lIntent.setAction("mSpots");
                if (e == null) {
                    mSpots = addSpotsToList(aListParseObject);
                    lIntent.putExtra(SUCCESS, true);
                }
                else{
                    lIntent.putExtra(SUCCESS, false);
                    Log.v("SSF", e.getMessage());
                }
                sendBroadcast(lIntent);
            }
        });
    }

    public static ArrayList<Spot> addSpotsToList(List<ParseObject> aListParseObject){
        ArrayList<Spot> lListSpots = new ArrayList<Spot>();
        for(ParseObject lParseObject : aListParseObject) {
            lListSpots.add(getSpotFromParseObject(lParseObject));
            addObjectToNews("spot", lParseObject);
        }
        return lListSpots;
    }

    public static Spot getSpotFromParseObject(ParseObject aParseObject){
        String lId = aParseObject.getObjectId();
        double lLatitude = aParseObject.getParseGeoPoint("localisation").getLatitude();
        double lLongitude = aParseObject.getParseGeoPoint("localisation").getLongitude();
        byte[] lImage = new byte[0];
        try {
            lImage = aParseObject.getParseFile("photo").getData();
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        float lRating = aParseObject.getLong("rating");
        String lDescription = aParseObject.getString("description");
        String lIdUser = aParseObject.getString("user");
        Spot lSpot = new Spot(lId, lLatitude, lLongitude, lImage, lRating, lDescription, lIdUser);
        return lSpot;
    }

    //------------------------------------------------------------ récupère la liste des commentaires

    public void getListCommentaries() {
        mCommentaries = new ArrayList<Commentary>();
        ParseQuery lParseQuery = new ParseQuery("Commentary");
        lParseQuery.orderByDescending("createdAt");
        lParseQuery.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> aListParseObject, ParseException e) {
                Intent lIntent = new Intent();
                lIntent.setAction("mCommentaries");
                if (e == null) {
                    mCommentaries = addCommentariesToList(aListParseObject);
                    lIntent.putExtra(SUCCESS, true);
                }
                else{
                    lIntent.putExtra(SUCCESS, false);
                    Log.v("SSF", e.getMessage());
                }
                sendBroadcast(lIntent);
            }
        });
    }

    public static ArrayList<Commentary> addCommentariesToList(List<ParseObject> aListParseObject){
        ArrayList<Commentary> lListCommentaries = new ArrayList<Commentary>();
        for(ParseObject lParseObject : aListParseObject) {
            lListCommentaries.add(getCommentaryFromParseObject(lParseObject));
            addObjectToNews("commentary", lParseObject);
        }
        return lListCommentaries;
    }

    public static Commentary getCommentaryFromParseObject(ParseObject aParseObject){
        String lId = aParseObject.getObjectId();
        String lDate = Static.dateToString(aParseObject.getCreatedAt(), "dd/MM/yyyy hh:mm");
        float lRating = aParseObject.getLong("rating");
        String lDescription = aParseObject.getString("description");
        String lIdUser = aParseObject.getParseObject("user").getObjectId();
        String lIdSpot = aParseObject.getParseObject("spot").getObjectId();
        Commentary lCommentary = new Commentary(lId, lDate, lRating, lDescription, lIdUser, lIdSpot);
        return lCommentary;
    }

    //------------------------------------------------------------ récupère la liste des users

    public void getListUsers() {
        mUsers = new ArrayList<User>();
        ParseQuery lParseQuery = new ParseQuery("_User");
        lParseQuery.orderByDescending("createdAt");
        lParseQuery.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> aListParseObject, ParseException e) {
                Intent lIntent = new Intent();
                lIntent.setAction("mUsers");
                if (e == null) {
                    mUsers = addUsersToList(aListParseObject);
                    lIntent.putExtra(SUCCESS, true);
                }
                else{
                    lIntent.putExtra(SUCCESS, false);
                    Log.v("SSF", e.getMessage());
                }
                sendBroadcast(lIntent);
            }
        });
    }

    public static ArrayList<User> addUsersToList(List<ParseObject> aListParseObject){
        ArrayList<User> lListUsers = new ArrayList<User>();
        for(ParseObject lParseObject : aListParseObject) {
            lListUsers.add(getUserFromParseObject(lParseObject));
            addObjectToNews("user", lParseObject);
        }
        return lListUsers;
    }

    public static User getUserFromParseObject(ParseObject aParseObject){
        String lId = aParseObject.getObjectId();
        String lUserName = aParseObject.getString("username");
        String lName = aParseObject.getString("name");
        User lUser = new User(lId, lUserName, lName);
        return lUser;
    }

    //------------------------------------------------------------ récupère la liste des favorite

    public void getListFavorites() {
        mFavorites = new ArrayList<Favorite>();
        ParseQuery lParseQuery = new ParseQuery("Favorite");
        lParseQuery.orderByDescending("createdAt");
        lParseQuery.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> aListParseObject, ParseException e) {
                Intent lIntent = new Intent();
                lIntent.setAction("mFavorites");
                if (e == null) {
                    mFavorites = addFavoritesToList(aListParseObject);
                    lIntent.putExtra(SUCCESS, true);
                }
                else{
                    lIntent.putExtra(SUCCESS, false);
                    Log.v("SSF", e.getMessage());
                }
                sendBroadcast(lIntent);
            }
        });
    }

    public static ArrayList<Favorite> addFavoritesToList(List<ParseObject> aListParseObject){
        ArrayList<Favorite> lListFavorites = new ArrayList<Favorite>();
        for(ParseObject lParseObject : aListParseObject) {
            lListFavorites.add(getFavoriteFromParseObject(lParseObject));
        }
        return lListFavorites;
    }

    public static Favorite getFavoriteFromParseObject(ParseObject aParseObject){
        String lId = aParseObject.getObjectId();
        String lIdUser = aParseObject.getParseObject("user").getObjectId();
        String lIdSpot = aParseObject.getParseObject("spot").getObjectId();
        Favorite lFavorite = new Favorite(lId, lIdUser, lIdSpot);
        return lFavorite;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mHandlerTask = new Runnable()
        {
            @Override
            public void run() {
                Intent lIntent = new Intent();
                lIntent.setAction("startDownload");
                sendBroadcast(lIntent);

                mNews = new ArrayList<HashMap<String, Object>>();
                getListSpots();
                getListCommentaries();
                getListUsers();
                getListFavorites();
                mHandler.postDelayed(mHandlerTask, 1000 * 60 * Static.mSynchronizationData);
            }
        };
        startRepeatingTask();
        return START_REDELIVER_INTENT;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static void addObjectToNews(String aType, ParseObject aParseObject){
        HashMap<String, Object> lHashMap = new HashMap<String, Object>();
        lHashMap.put("type", aType);
        lHashMap.put("id", aParseObject.getObjectId());
        lHashMap.put("date", aParseObject.getCreatedAt());
        mNews.add(lHashMap);
    }

    public static void sortNewsList() {
        Collections.sort(mNews, new Comparator<HashMap<String, Object>>(){
            public int compare(HashMap<String, Object> lHM1, HashMap<String, Object> lHM2){
                Date lDateHM1 = (Date) lHM1.get("date");
                Date lDateHM2 = (Date) lHM2.get("date");
                if (lDateHM1.after(lDateHM2))
                    return -1;
                else if (lDateHM1.after(lDateHM2) || lDateHM1.equals(lDateHM2))
                    return 0;
                else
                    return 1;
            }
        });
    }

    void startRepeatingTask()
    {
        mHandlerTask.run();
    }

    void stopRepeatingTask()
    {
        mHandler.removeCallbacks(mHandlerTask);
    }

    
}