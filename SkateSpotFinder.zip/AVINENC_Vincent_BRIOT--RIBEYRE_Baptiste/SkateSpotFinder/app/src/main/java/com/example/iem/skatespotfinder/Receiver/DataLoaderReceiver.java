package com.example.iem.skatespotfinder.Receiver;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import com.example.iem.skatespotfinder.Activities.MainActivity;
import com.example.iem.skatespotfinder.Activities.SpotDetailActivity;
import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Class.Spot;
import com.example.iem.skatespotfinder.Class.User;
import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Services.DataLoader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by iem on 13/01/15.
 */
public class DataLoaderReceiver extends BroadcastReceiver {
    private static final String TAG = "DataLoaderReceiver";
    Context mContext;
    ProgressDialog mPDialog;
    static boolean mStart = false,
            mSpotsDone = false,
            mCommentariesDone = false,
            mUsersDone = false ,
            mFavoritesDone = false;
    void initBoolean(){
        mStart = false;
        mSpotsDone = false;
        mCommentariesDone = false;
        mUsersDone = false ;
        mFavoritesDone = false;
    }
    boolean mFinish(){return mStart && mSpotsDone && mCommentariesDone && mUsersDone && mFavoritesDone;}
    @Override
    public void onReceive(Context context, Intent intent) {

        mContext = context;
        boolean success = intent.getBooleanExtra("success", false);
            switch (intent.getAction()) {
                case "startDownload":
                    mStart = true;
                    if(mFinish()){
                        fillListNews(context);
                        MainActivity.mProgressDialog.dismiss();
                        initBoolean();
                    }
                    Log.d(TAG, "action: startDownload");
                    //MainActivity.mProgressDialog.setMessage("Synchronisation en cours...");
                    MainActivity.displayProgressDialog();

                    //Toast.makeText(mContext, "Synchronisation en cours "+mStart+" - "+mFinish(), Toast.LENGTH_LONG).show();
                case "mSpots":
                    mSpotsDone = true;
                    if(mFinish()){
                        fillListNews(context);
                        MainActivity.mProgressDialog.dismiss();
                    }
                    //Toast.makeText(mContext, "Synchronisation des spots impossible ! "+ mSpotsDone+" - "+mFinish(), Toast.LENGTH_LONG).show();
                    break;
                case "mCommentaries":
                    mCommentariesDone = true;
                    if(mFinish()){
                        fillListNews(context);
                        MainActivity.mProgressDialog.dismiss();
                        initBoolean();
                    }
                    //Toast.makeText(mContext, "Synchronisation des commentaries impossible ! "+ mCommentariesDone+" - "+mFinish(), Toast.LENGTH_LONG).show();
                    break;
                case "mUsers":
                    mUsersDone = true;
                    if(mFinish()){
                        fillListNews(context);
                        MainActivity.mProgressDialog.dismiss();
                        initBoolean();
                    }
                    //Toast.makeText(mContext, "Synchronisation des users impossible ! " + mUsersDone+" - "+mFinish(), Toast.LENGTH_LONG).show();
                    break;
                case "mFavorites":
                    mFavoritesDone = true;
                    if(mFinish()){
                        fillListNews(context);
                        MainActivity.mProgressDialog.dismiss();
                        initBoolean();
                    }
                    //Toast.makeText(mContext, "Synchronisation des favorites impossible ! "+ mFavoritesDone+" - "+mFinish(), Toast.LENGTH_LONG).show();
                    break;
            }

    }
    public void fillListNews(Context context){
        DataLoader.sortNewsList();
        ArrayList<HashMap<String, String>> lNews = new ArrayList<HashMap<String, String>>();
        for(HashMap<String, Object> lEntity : DataLoader.mNews){
            switch(lEntity.get("type").toString()){
                case "spot":
                    for(Spot lSpot : DataLoader.mSpots){
                        if(lSpot.getId().equals(lEntity.get("id"))){
                            for(User lUser : DataLoader.mUsers){
                                if(lUser.getId().equals(lSpot.getIdUser())){
                                    HashMap<String, String> lHashMap = new HashMap<String, String>();
                                    lHashMap.put("date", Static.dateToString((Date) lEntity.get("date"), "dd/MM/yyyy hh:mm"));
                                    lHashMap.put("idSpot", lSpot.getId());
                                    String lMessage = lUser.getUserName() + " a ajouté un spot.";
                                    lHashMap.put("message", lMessage);
                                    lNews.add(lHashMap);
                                }
                            }
                        }
                    }
                    break;
                case "commentary":
                    for(Commentary lCommentary : DataLoader.mCommentaries){
                        if(lCommentary.getId().equals(lEntity.get("id"))){
                            for(User lUser : DataLoader.mUsers){
                                if(lUser.getId().equals(lCommentary.getIdUser())){
                                    HashMap<String, String> lHashMap = new HashMap<String, String>();
                                    lHashMap.put("date", Static.dateToString((Date) lEntity.get("date"), "dd/MM/yyyy hh:mm"));
                                    lHashMap.put("idSpot", lCommentary.getIdSpot());
                                    String lMessage = lUser.getUserName() + " a commenté un spot.";
                                    lHashMap.put("message", lMessage);
                                    lNews.add(lHashMap);
                                }
                            }
                        }
                    }
                    break;
            }
        }
        final SimpleAdapter lSimpleAdapter = new SimpleAdapter(context, lNews, R.layout.news_row_layout, new String[]{"message", "date"}, new int[]{R.id.textViewNews, R.id.textViewDate});
        MainActivity.mListViewNews.setAdapter(lSimpleAdapter);
        MainActivity.mListViewNews.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> lHashMap = (HashMap<String, String>) lSimpleAdapter.getItem(position);
                String lIdSpot = lHashMap.get("idSpot");
                for(Spot lSpot : DataLoader.mSpots){
                    if(lSpot.getId().equals(lIdSpot)){
                        Intent lIntent = new Intent(mContext, SpotDetailActivity.class);
                        lIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        lIntent.putExtra("Spot", lSpot);
                        mContext.startActivity(lIntent);
                    }
                }
            }
        });
    }
}
