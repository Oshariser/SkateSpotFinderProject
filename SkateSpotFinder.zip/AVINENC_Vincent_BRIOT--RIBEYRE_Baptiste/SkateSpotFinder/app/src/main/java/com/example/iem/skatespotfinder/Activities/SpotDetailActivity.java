package com.example.iem.skatespotfinder.Activities;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.iem.skatespotfinder.Adapter.AdapterComment;
import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Services.DataLoader;
import com.example.iem.skatespotfinder.Class.Favorite;
import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Spot;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.util.List;


public class SpotDetailActivity extends Activity {

    private Spot mSpot;
    private CheckBox mCheckboxFavorite;
    private ImageView mImageViewSpot;
    private TextView mTextViewDescription;
    private Button mButtonAddComment;
    private ListView mListViewCommentary;
    private List<Commentary> mCommentaries;
    private RatingBar mRatingBarSpotDetail;
    private RatingBar mRatingBarTotal;
    private EditText mEditTextNewCommentary;
    private boolean mIsRating = false;
    LinearLayout mLinearLayoutComment;
    private float mTotalRating = 0;
    private boolean mIsFavoriteSpot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spot_detail);

        mSpot = (Spot)getIntent().getSerializableExtra("Spot");
        mListViewCommentary = (ListView)findViewById(R.id.listViewCommentary);
        fillListView();
        mTotalRating = Static.getTotalRatingFromSpot(mCommentaries, mSpot);

        mCheckboxFavorite = (CheckBox)findViewById(R.id.checkboxFavorite);
        mImageViewSpot = (ImageView)findViewById(R.id.imageViewSpotDetail);
        mTextViewDescription = (TextView)findViewById(R.id.textViewSpotDetail);
        mEditTextNewCommentary = (EditText)findViewById(R.id.editTextNewComment);
        mLinearLayoutComment = (LinearLayout)findViewById(R.id.linearLayoutAddComment);
        mRatingBarSpotDetail = (RatingBar)findViewById(R.id.ratingBarSpotDetail);

        if(!canAddComment()){
            mLinearLayoutComment.setVisibility(View.GONE);
            mRatingBarSpotDetail.setVisibility(View.GONE);
        }

        mRatingBarTotal = (RatingBar)findViewById(R.id.ratingBarTotal);

        for(Favorite iFavorite : DataLoader.mFavorites){
            if(iFavorite.getIdUser().equals(ParseUser.getCurrentUser().getObjectId()) && iFavorite.getIdSpot().equals(mSpot.getId())){
                mIsFavoriteSpot = true;
            }
        }

        if(mIsFavoriteSpot) {
            mCheckboxFavorite.setChecked(true);
            mCheckboxFavorite.setEnabled(false);
        }

        mCheckboxFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mCheckboxFavorite.isChecked()){
                    Favorite lFavorite = new Favorite(null, ParseUser.getCurrentUser().getObjectId(), mSpot.getId());
                    DataLoader.mFavorites.add(lFavorite);
                    ParseObject lParseObject = new ParseObject("Favorite");
                    lParseObject.put("spot", ParseObject.createWithoutData("Spot", lFavorite.getIdSpot()));
                    lParseObject.put("user", ParseObject.createWithoutData("_User", lFavorite.getIdUser()));
                    lParseObject.saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            if(e == null){
                                Toast.makeText(getBaseContext(),"New favorite added", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getBaseContext(), e.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        mRatingBarTotal.setRating(mTotalRating / mCommentaries.size());

        mImageViewSpot.setImageBitmap(mSpot.getBitmapImage());

        mTextViewDescription.setText(mSpot.getDescription());


        mRatingBarSpotDetail.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                mIsRating = true;
            }
        });

        mButtonAddComment = (Button)findViewById(R.id.buttonAddComment);
        mButtonAddComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(mIsRating) {
                    Commentary lCommentary = new Commentary(mEditTextNewCommentary.getText().toString(), ParseUser.getCurrentUser().getObjectId(), mSpot.getId());
                    DataLoader.mCommentaries.add(lCommentary);
                    ParseObject lParseObject = new ParseObject("Commentary");
                    lParseObject.put("rating", mRatingBarSpotDetail.getRating());
                    lParseObject.put("user", ParseObject.createWithoutData("_User", lCommentary.getIdUser()));
                    lParseObject.put("spot", ParseObject.createWithoutData("Spot", mSpot.getId()));

                    if(!(mTextViewDescription.getText().toString().equals(""))) {
                        lParseObject.put("description", lCommentary.getDescription());
                    }

                    lParseObject.saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            if (e == null) {
                                mLinearLayoutComment.setVisibility(View.GONE);
                                mRatingBarSpotDetail.setVisibility(View.GONE);
                                fillListView();
                                Toast.makeText(getBaseContext(), "New comment is added", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getBaseContext(), "Error :" + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });

    }

    private void fillListView() {
        if(mCommentaries != null) mCommentaries.clear();
        mCommentaries = Static.getCommentariesFromSpot(mSpot);
        ArrayAdapter<Commentary> lAdapter = new AdapterComment(this, mCommentaries);
        mListViewCommentary.setAdapter(lAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_spot_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent mActivity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private boolean canAddComment(){
        for(Commentary iComment : DataLoader.mCommentaries){
            if(iComment.getIdUser().equals(ParseUser.getCurrentUser().getObjectId()) && iComment.getIdSpot().equals(mSpot.getId())){
                return false;
            }
        }
        return true;
    }

}
