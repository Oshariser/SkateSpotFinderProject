package com.example.iem.skatespotfinder.Class;

/**
 * Created by iem on 14/01/15.
 */
public class Commentary {

    private String mId;
    private String mDate;
    private float mRating;
    private String mDescription;
    private String mIdUser;
    private String mIdSpot;

    public Commentary(String aId, String aDate, float aRating, String aDescription, String aIdUser, String aIdSpot){
        this.setId(aId);
        this.setDate(aDate);
        this.setRating(aRating);
        this.setDescription(aDescription);
        this.setIdUser(aIdUser);
        this.setIdSpot(aIdSpot);
    }

    public Commentary(String aDescription, String aIdUser, String aIdSpot){
        mDescription = aDescription;
        mIdUser = aIdUser;
        mIdSpot = aIdSpot;
    }

    public float getRating() {
        return mRating;
    }

    public void setRating(float mRating) {
        this.mRating = mRating;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public String getIdUser() {
        return mIdUser;
    }

    public void setIdUser(String mIdUser) {
        this.mIdUser = mIdUser;
    }

    public String getId() {
        return mId;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public String getIdSpot() {
        return mIdSpot;
    }

    public void setIdSpot(String mIdSpot) {
        this.mIdSpot = mIdSpot;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String mDate) {
        this.mDate = mDate;
    }
}
