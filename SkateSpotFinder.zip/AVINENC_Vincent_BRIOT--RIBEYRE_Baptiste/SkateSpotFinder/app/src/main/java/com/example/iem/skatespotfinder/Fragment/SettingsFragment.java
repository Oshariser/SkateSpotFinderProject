package com.example.iem.skatespotfinder.Fragment;

import android.os.Bundle;
import android.preference.PreferenceFragment;

import com.example.iem.skatespotfinder.R;

/**
 * Created by Vincent on 29/11/2014.
 */
public class SettingsFragment extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.skatespotfinder_preferences);
    }
}
