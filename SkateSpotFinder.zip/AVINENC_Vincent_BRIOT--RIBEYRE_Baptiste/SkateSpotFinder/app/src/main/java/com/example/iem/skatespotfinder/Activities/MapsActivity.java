package com.example.iem.skatespotfinder.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.iem.skatespotfinder.Services.DataLoader;
import com.example.iem.skatespotfinder.Class.GpsTracker;
import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Spot;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapsActivity extends FragmentActivity {

    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    private Map<Marker, Spot> mMapSpotMarker = new HashMap<Marker, Spot>();
    private Spinner mSpinnerDistance;
    private Spinner mSpinnerFilter;
    private static float mZoom;
    private HashMap<Integer, Float> mDistance;
    private Circle mCircle = null;
    private ArrayAdapter<Integer> mAdapterDistance;
    private ArrayAdapter<String> mAdapterFilter;

    private static final String mFilter1 = "Tous";
    private static final String mFilter2 = "Favoris";
    private static final String mFilter3 = "A proximité";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        initSpinnerDistance();
        initSpinnerFilter();
        setUpMapIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p/>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p/>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p/>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
        loadGoogleMap();
    }

    private LatLng getCurrentPosition() {
        LatLng lCurrentPosition = null;
        GpsTracker lGpsTracker = new GpsTracker(this);
        if(lGpsTracker.canGetLocation()){
            lCurrentPosition = new LatLng(lGpsTracker.getLatitude(), lGpsTracker.getLongitude());
        }
        return lCurrentPosition;
    }

    private void adaptTheZoom(){
        mZoom = mDistance.get(mSpinnerDistance.getSelectedItem());
        if(getCurrentPosition() != null) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(getCurrentPosition(), mZoom));
        }

        /*BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
        LatLng lCurrentPosition = getCurrentPosition();
        MarkerOptions lMarkerOptions = new MarkerOptions().position(lCurrentPosition);
        lMarkerOptions.icon(bitmapDescriptor);
        lMarkerOptions.draggable(false);
        mMap.addMarker(lMarkerOptions);*/

        adaptTheCircle();
    }

    private void adaptTheCircle(){
        if(mCircle != null) {
            mCircle.remove();
        }
        double lRadius = 0;
        for (Map.Entry<Integer, Float> lEntry : mDistance.entrySet()) {
            if (lEntry.getValue() == mDistance.get(mSpinnerDistance.getSelectedItem())){
                lRadius = lEntry.getKey();
            }
        }
        mCircle = mMap.addCircle(new CircleOptions().center(getCurrentPosition()).radius(lRadius * 1000).strokeColor(Color.RED)/*.fillColor(Color.BLUE)*/);
    }

    private void initSpinnerDistance(){
        mSpinnerDistance = (Spinner) findViewById(R.id.sp_map_distance);
        mDistance = new HashMap<Integer, Float>();
        mDistance.put(1, 14.25f);
        mDistance.put(5, 11.93f);
        mDistance.put(10, 10.93f);
        mDistance.put(50, 8.608f);
        mDistance.put(100, 7.605f);
        ArrayList<Integer> lKeyDistance = new ArrayList<Integer>();
        for(Integer lInt : mDistance.keySet()){
            lKeyDistance.add(lInt);
        }
        Collections.sort(lKeyDistance);
        mAdapterDistance = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item, lKeyDistance);
        mSpinnerDistance.setAdapter(mAdapterDistance);
        mSpinnerDistance.setSelection(2);
        mSpinnerDistance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadGoogleMap();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void initSpinnerFilter(){
        mSpinnerFilter = (Spinner) findViewById(R.id.sp_map_filter);
        ArrayList<String> lKeyFilter = new ArrayList<String>();
        lKeyFilter.add(mFilter1);
        lKeyFilter.add(mFilter2);
        lKeyFilter.add(mFilter3);
        mAdapterFilter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lKeyFilter);
        mSpinnerFilter.setAdapter(mAdapterFilter);
        mSpinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadGoogleMap();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void loadGoogleMap(){
        mMap.clear();
        adaptTheZoom();

        String lFilter = mSpinnerFilter.getSelectedItem().toString();
        List<Spot> lListSpot = null;
        switch(lFilter){
            case mFilter1 :
                lListSpot = DataLoader.mSpots;
                break;
            case mFilter2 :
                lListSpot = Static.getFavoritesSpots();
                break;
            case mFilter3 :
                lListSpot = new ArrayList<Spot>();
                LatLngBounds lLatLngBounds = mMap.getProjection().getVisibleRegion().latLngBounds;

                LatLng lNortheast = lLatLngBounds.northeast;
                double lLatNortheast = lNortheast.latitude;
                double lLngNortheast = lNortheast.longitude;

                LatLng lSouthwest = lLatLngBounds.southwest;
                double lLatSouthwest = lSouthwest.latitude;
                double lLngSouthwest = lSouthwest.longitude;

                for(Spot lSpot : DataLoader.mSpots){
                    if(lSpot.getLatitude() <= lLatNortheast && lSpot.getLongitude() <= lLngNortheast && lSpot.getLatitude() >= lLatSouthwest && lSpot.getLongitude() >= lLngSouthwest){
                        lListSpot.add(lSpot);
                    }
                }
                break;
        }
        Marker lMarker;
        MarkerOptions lMarkerOptions;
        List<Address> lAdresses;

        BitmapDescriptor bitmapDescriptor = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
        for(Spot lSpot : lListSpot){
            lAdresses = Static.getAddressFromLatLong(lSpot.getLatitude(), lSpot.getLongitude(), getBaseContext());
            lMarkerOptions = new MarkerOptions().position(new LatLng(lSpot.getLatitude(), lSpot.getLongitude())).infoWindowAnchor(0f, 0f);
            if(lAdresses != null && lAdresses.size() > 0){
                lMarkerOptions.snippet(lAdresses.get(0).getAddressLine(0) + "\n" + lAdresses.get(0).getAddressLine(1) + "\n" + lAdresses.get(0).getAddressLine(2));
            }
            if(Static.getFavoritesSpots().contains(lSpot)){
                lMarkerOptions.icon(bitmapDescriptor);
            }
            lMarker = mMap.addMarker(lMarkerOptions);

            mMapSpotMarker.put(lMarker, lSpot);
        }

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                marker.showInfoWindow();
                return true;
            }
        });

        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Intent lIntentSpotDetail = new Intent(MapsActivity.this, SpotDetailActivity.class);
                lIntentSpotDetail.putExtra("Spot", mMapSpotMarker.get(marker));
                startActivity(lIntentSpotDetail);
            }
        });

        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
            @Override
            public View getInfoWindow(Marker marker) {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker) {
                View lView = getLayoutInflater().inflate(R.layout.info_window_layout, null);
                TextView lTextView = (TextView) lView.findViewById(R.id.textViewDescription);
                ImageView lImageView = (ImageView) lView.findViewById(R.id.imageViewSpotMap);
                RatingBar lRatingBar = (RatingBar) lView.findViewById(R.id.ratingBarSpotMap);
                lTextView.setText(marker.getSnippet());
                lTextView.setTextSize(10);
                lImageView.setImageBitmap(mMapSpotMarker.get(marker).getBitmapImage());
                lRatingBar.setRating(Static.getTotalRatingFromSpot(Static.getCommentariesFromSpot(mMapSpotMarker.get(marker)), mMapSpotMarker.get(marker)));
                return lView;
            }
        });
    }

    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        MainActivity.dismissProgressDialog();
    }
}
