package com.example.iem.skatespotfinder.Class;

/**
 * Created by iem on 14/01/15.
 */
public class User {

    private String mId;
    private String mUserName;
    private String mName;

    public User(String aId, String aUserName, String aName){
        this.setId(aId);
        this.setUserName(aUserName);
        this.setName(aName);
    }

    public String getId() {
        return mId;
    }

    public void setId(String mId) {
        this.mId = mId;
    }

    public String getUserName() {
        return mUserName;
    }

    public void setUserName(String mUserName) {
        this.mUserName = mUserName;
    }

    public String getName() {
        return mName;
    }

    public void setName(String mName) {
        this.mName = mName;
    }
}

