package com.example.iem.skatespotfinder.Adapter;

import android.app.Activity;
import android.content.Intent;
import android.location.Address;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Spot;

import java.util.List;

/**
 * Created by root on 1/8/15.
 */
public class AdapterSpot extends ArrayAdapter<Spot>{

    private final List<Spot> mSpots;
    private Activity mContext;

    public AdapterSpot(Activity aContext, List<Spot> aSpots) {
        super(aContext, R.layout.row_layout, aSpots);
        this.mContext = aContext;
        this.mSpots = aSpots;
    }

    static class ViewHolder {
        protected ImageView imageView;
        protected TextView textView;
        protected ImageButton imageButton;
    }

    @Override
    public View getView(final int aPosition, View aConvertView, ViewGroup aParent) {
        View lView = null;
        if (aConvertView == null) {
            LayoutInflater lInflator = mContext.getLayoutInflater();
            lView = lInflator.inflate(R.layout.row_layout, null);
            final ViewHolder lViewHolder = new ViewHolder();
            lViewHolder.imageView = (ImageView) lView.findViewById(R.id.imageView);
            lViewHolder.textView = (TextView) lView.findViewById(R.id.textView);
            lViewHolder.imageButton = (ImageButton) lView.findViewById(R.id.imageButton);
            lViewHolder.imageButton
                    .setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + mSpots.get(aPosition).getLatitude() + "," + mSpots.get(aPosition).getLongitude()));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            mContext.startActivity(intent);
                        }
                    });
            lView.setTag(lViewHolder);
            lViewHolder.imageButton.setTag(mSpots.get(aPosition));
        } else {
            lView = aConvertView;
            ((ViewHolder) lView.getTag()).imageButton.setTag(mSpots.get(aPosition));
        }
        ViewHolder holder = (ViewHolder) lView.getTag();
        List<Address> lAddresses = Static.getAddressFromLatLong(mSpots.get(aPosition).getLatitude(), mSpots.get(aPosition).getLongitude(), getContext());
        if(lAddresses != null) {
            holder.textView.setText(lAddresses.get(0).getAddressLine(0) + "\n" + lAddresses.get(0).getAddressLine(1) + "\n" + lAddresses.get(0).getAddressLine(2));
        }
        holder.imageView.setImageBitmap(mSpots.get(aPosition).getBitmapImage());

        return lView;
    }


}
