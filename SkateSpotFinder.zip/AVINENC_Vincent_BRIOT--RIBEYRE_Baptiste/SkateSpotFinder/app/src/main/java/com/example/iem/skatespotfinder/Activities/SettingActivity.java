package com.example.iem.skatespotfinder.Activities;

import android.app.Activity;
import android.os.Bundle;

import com.example.iem.skatespotfinder.Fragment.SettingsFragment;

/**
 * Created by Vincent on 03/02/2015.
 */
public class SettingActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction()
                .replace(android.R.id.content, new SettingsFragment())
                .commit();
    }
}
