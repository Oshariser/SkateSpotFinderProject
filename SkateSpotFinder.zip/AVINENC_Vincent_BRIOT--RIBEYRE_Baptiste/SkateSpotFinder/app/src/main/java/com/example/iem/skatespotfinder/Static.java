package com.example.iem.skatespotfinder;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;

import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Class.Favorite;
import com.example.iem.skatespotfinder.Class.Spot;
import com.example.iem.skatespotfinder.Services.DataLoader;
import com.parse.ParseUser;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Created by iem on 09/01/15.
 */
public class Static {

    public static int mSynchronizationData = 60;

    public static String dateToString(Date date, String format) {
        SimpleDateFormat df = new SimpleDateFormat(format);
        return df.format(date);
    }

    public static List<Address> getAddressFromLatLong(double aLatitude, double aLongitude, Context aContext) {
        Geocoder geocoder;
        List<Address> addresses = null;
        geocoder = new Geocoder(aContext, Locale.getDefault());
        try {
            addresses = geocoder.getFromLocation(aLatitude, aLongitude, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(addresses != null && addresses.size() > 0) {
            return addresses;
        }

        return null;
    }

    public static List<Commentary> getCommentariesFromSpot(Spot aSpot) {
        List<Commentary> lCommentaries = new ArrayList<>();
        for(Commentary iComment : DataLoader.mCommentaries) {
            if(iComment.getIdSpot().equals(aSpot.getId())){
                lCommentaries.add(iComment);
            }
        }
       return lCommentaries;
    }

    public static float getTotalRatingFromSpot(List<Commentary> aCommentaries, Spot aSpot){
        float lTotalRating = 0;
        for(Commentary iComment : aCommentaries){
            if(iComment.getIdSpot().equals(aSpot.getId())){
                lTotalRating += iComment.getRating();
            }
        }

        return lTotalRating / aCommentaries.size();
    }

    public static List<Spot> getFavoritesSpots() {
        ParseUser lParseUser = ParseUser.getCurrentUser();
        String lIdUser = lParseUser.getObjectId();
        List<Spot> lListFavoritesSpot = new ArrayList<Spot>();
        for(Favorite lFavorite : DataLoader.mFavorites){
            if(lFavorite.getIdUser().equals(lIdUser)){
                String lIdSpot = lFavorite.getIdSpot();
                for(Spot lSpot : DataLoader.mSpots){
                    if(lSpot.getId() != null && lSpot.getId().equals(lIdSpot)){
                        lListFavoritesSpot.add(lSpot);
                    }
                }
            }
        }
        return lListFavoritesSpot;
    }
}

