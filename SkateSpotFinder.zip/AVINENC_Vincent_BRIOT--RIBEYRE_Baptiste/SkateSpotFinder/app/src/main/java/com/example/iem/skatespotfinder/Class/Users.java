package com.example.iem.skatespotfinder.Class;

import com.example.iem.skatespotfinder.Services.DataLoader;

public class Users{

    public static String getNameById(String aId){
        String lUserName = null;
        for(User iUser : DataLoader.mUsers){
            if(iUser.getId().equals(aId)){
                lUserName = iUser.getUserName();
            }
        }
        return lUserName;
    }

}
