package com.example.iem.skatespotfinder.Class;

import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Class.Spot;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 1/15/15.
 */
public class GroupSpotCommentary {
    private Spot mSpot;
    private List<Commentary> mCommentaries = new ArrayList<Commentary>();

    public GroupSpotCommentary(Spot mSpot) {
        this.mSpot = mSpot;
    }

    public Spot getSpot() {
        return mSpot;
    }

    public List<Commentary> getCommentaries() {
        return mCommentaries;
    }
}
