package com.example.iem.skatespotfinder.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import com.example.iem.skatespotfinder.Services.DataLoader;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Static;
import com.parse.Parse;
import com.parse.ParseUser;
import com.parse.ui.ParseLoginBuilder;


public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";
    private ImageButton mImageButtonMap;
    private ImageButton mImageButtonAddSpot;
    private ImageButton mImageButtonFavorite;
    private ImageButton mImageButtonSpot;
    public static ListView mListViewNews;
    public static ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mProgressDialog = new ProgressDialog(this);

        setUpSynchronisation();

        Parse.initialize(this, "QTQlI0JRr2ZqU22Zfekt22saXkWfNwqd0eUS3tJD", "d7w6ruFuWmLLlShtxdqe898ttl0FkJqTtgNtN2cE");

        if(ParseUser.getCurrentUser() == null) {
            ParseLoginBuilder lPLBuilder = new ParseLoginBuilder(MainActivity.this);
            startActivityForResult(lPLBuilder.build(), 0);
        } else {
            launchDataLoader();
            Log.d(TAG, "launchDataLoader from user already connected");
        }

        mImageButtonMap = (ImageButton) findViewById(R.id.imageButtonMap);
        mImageButtonMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayProgressDialog();
                mProgressDialog.setMessage("Loading map ...");
                Intent lIntentMap = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(lIntentMap);
            }
        });

        mImageButtonAddSpot = (ImageButton) findViewById(R.id.imageButtonAddSpot);
        mImageButtonAddSpot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lIntentAddSpot = new Intent(getApplicationContext(), AddSpotActivity.class);
                startActivity(lIntentAddSpot);
            }
        });

        mImageButtonFavorite = (ImageButton) findViewById(R.id.imageButtonFavorite);
        mImageButtonFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lIntentFavorite = new Intent(getApplicationContext(), FavoriteActivity.class);
                startActivity(lIntentFavorite);
            }
        });

        mImageButtonSpot = (ImageButton) findViewById(R.id.imageButtonSpot);
        mImageButtonSpot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lIntentSpot = new Intent(getApplicationContext(), SpotActivity.class);
                startActivity(lIntentSpot);
            }
        });
        mListViewNews = (ListView) findViewById(R.id.listViewNews);
    }

    public int setUpSynchronisation() {
        SharedPreferences lSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        Static.mSynchronizationData = Integer.parseInt(lSharedPreferences.getString("synchronizationData", "60"));
        return Static.mSynchronizationData;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent mActivity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent lIntent = new Intent(getApplicationContext(), SettingActivity.class);
            startActivityForResult(lIntent, 1);
            return true;
        } else if (id == R.id.action_logOut){
            ParseUser.logOut();
            ParseLoginBuilder lPLBuilder = new ParseLoginBuilder(MainActivity.this);
            startActivityForResult(lPLBuilder.build(), 0);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 0){
            if(resultCode == RESULT_OK){
                ParseUser lCurrentUser = ParseUser.getCurrentUser();
                if(lCurrentUser != null) {
                    launchDataLoader();
                    Log.d(TAG, "launchDataLoader onActivityResult");
                } else {
                    Toast.makeText(this, "Error ParseUser is null", Toast.LENGTH_LONG).show();
                }
            } else if (resultCode == RESULT_CANCELED) {
                finish();
            }
        } else if(resultCode == 1){
            setUpSynchronisation();
        }
    }

    public void launchDataLoader(){
        Intent lIntent = new Intent(MainActivity.this, DataLoader.class);
        this.getApplicationContext().startService(lIntent);
    }

    public static void displayProgressDialog(){
        mProgressDialog.setMessage("Synchronisation en cours ...");
        mProgressDialog.show();
    }

    public static void dismissProgressDialog(){
        if(mProgressDialog.isShowing()){
            mProgressDialog.dismiss();
        }
    }

}