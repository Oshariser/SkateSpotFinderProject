package com.example.iem.skatespotfinder.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.iem.skatespotfinder.Class.GpsTracker;
import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Spot;
import com.example.iem.skatespotfinder.Services.DataLoader;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Date;


public class AddSpotActivity extends Activity {

    private double mLatitude;
    private double mLongitude;
    private File mFile;
    private static final int TAKE_PICTURE = 1;
    private ImageView mImageViewSpot;
    private Button mButtonBrowse;
    private EditText mEditTextDescription;
    private Button mButtonAddSpot;
    private final static String TAG = "AddSpotActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_spot);

        mImageViewSpot = (ImageView)findViewById(R.id.imageViewSpot);
        mButtonBrowse = (Button) findViewById(R.id.buttonBrowse);
        mButtonBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });
        mEditTextDescription = (EditText)findViewById(R.id.editTextDescription);
        mButtonAddSpot = (Button)findViewById(R.id.buttonAddSpot);
        mButtonAddSpot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mFile != null) {
                    getCurrentLocation();
                    Spot lSpot = new Spot(mLatitude, mLongitude, mFile, mEditTextDescription.getText().toString(), ParseUser.getCurrentUser().getObjectId());
                    DataLoader.mSpots.add(lSpot);
                    addSpot(lSpot);
                } else {
                    Toast.makeText(getBaseContext(),"Vous devez prendre une photo du nouveau spot !",Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    private void takePicture() {
        String lName = Static.dateToString(new Date(), "yyyyMMddhhmmss");
        mFile = new File(Environment.getExternalStorageDirectory(), lName + ".jpg");
        Intent lIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        lIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mFile));
        startActivityForResult(lIntent, TAKE_PICTURE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_spot, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void addSpot(final Spot aSpot){
        final ParseObject lParseObject = new ParseObject("Spot");
        lParseObject.put("localisation", new ParseGeoPoint(aSpot.getLatitude(), aSpot.getLongitude()));
        ParseFile lParseFile = new ParseFile(mFile.getName(), aSpot.getImage());
        lParseObject.put("photo", lParseFile);
        lParseObject.put("description", aSpot.getDescription());
        final ProgressDialog lProgressDialog = new ProgressDialog(this);
        lProgressDialog.setMessage("Upload new spot ...");
        lProgressDialog.setCanceledOnTouchOutside(false);
        lProgressDialog.show();

        lParseObject.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                if (e == null) {
                    DataLoader.mSpots.add(aSpot);
                    lProgressDialog.dismiss();
                } else {
                    lProgressDialog.dismiss();
                    Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void getCurrentLocation() {
        GpsTracker lGpsTracker = new GpsTracker(this);
        if(lGpsTracker.canGetLocation()){
            mLongitude = lGpsTracker.getLongitude();
            mLatitude = lGpsTracker.getLatitude();
        } else {
            lGpsTracker.showSettingsAlert();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case TAKE_PICTURE:
                if (resultCode == Activity.RESULT_OK) {
                    setImageSpot();
                }
        }
    }

    private void setImageSpot() {
        try {
            FileInputStream lInputStream = new FileInputStream(mFile);
            BitmapFactory.Options lBitMapOption = new BitmapFactory.Options();
            lBitMapOption.inSampleSize = 10;
            Bitmap lBitmap = BitmapFactory.decodeStream(lInputStream, null, lBitMapOption);
            mImageViewSpot.setImageBitmap(lBitmap);
        } catch (FileNotFoundException e) {
            Log.e(TAG, e.getMessage());
        }
    }


}