package com.example.iem.skatespotfinder.Activities;

import android.app.Activity;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListView;
import android.widget.Spinner;

import com.example.iem.skatespotfinder.Adapter.MyExpandableListAdapter;
import com.example.iem.skatespotfinder.Class.Commentary;
import com.example.iem.skatespotfinder.Static;
import com.example.iem.skatespotfinder.Services.DataLoader;
import com.example.iem.skatespotfinder.Class.GroupSpotCommentary;
import com.example.iem.skatespotfinder.R;
import com.example.iem.skatespotfinder.Class.Spot;

import java.util.ArrayList;
import java.util.List;


public class SpotActivity extends Activity {

    private ExpandableListView mExpandableListViewSpot;
    private Spinner mSpinnerFilter;
    private static final String FILTER_ALL = "Tous";
    private static final String FILTER_FAVORITE = "Favoris";
    SparseArray<GroupSpotCommentary> mGroupSpotsCommentaries = new SparseArray<GroupSpotCommentary>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spot);
        mSpinnerFilter = (Spinner) findViewById(R.id.spinnerFilter);
        fillSpinner();
        mSpinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(mSpinnerFilter.getSelectedItem().toString().equals(FILTER_FAVORITE)){
                    fillSparseArray(Static.getFavoritesSpots());
                } else {
                    fillSparseArray(DataLoader.mSpots);
                }

                fillExpandableListView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mExpandableListViewSpot = (ExpandableListView)findViewById(R.id.expandableListViewSpot);

        fillExpandableListView();
    }

    private void fillExpandableListView(){
        MyExpandableListAdapter lAdapter = new MyExpandableListAdapter(this,
                mGroupSpotsCommentaries);
        mExpandableListViewSpot.setAdapter(lAdapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_spot, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent mActivity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void fillSparseArray(List<Spot> aSpots) {
        mGroupSpotsCommentaries.clear();
        int lKey = 0;
        for (Spot iSpot : aSpots) {
            GroupSpotCommentary lGroup = new GroupSpotCommentary(iSpot);
            for (Commentary iComment : DataLoader.mCommentaries) {
                if (iSpot.getId().equals(iComment.getIdSpot())) {
                    lGroup.getCommentaries().add(iComment);
                }
            }
            mGroupSpotsCommentaries.append(lKey, lGroup);
            lKey++;
        }
    }

    private void fillSpinner(){
        ArrayList<String> lKeyFilter = new ArrayList<String>();
        lKeyFilter.add(FILTER_ALL);
        lKeyFilter.add(FILTER_FAVORITE);
        ArrayAdapter<String> lAdapterFilter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lKeyFilter);
        mSpinnerFilter.setAdapter(lAdapterFilter);
    }
}
